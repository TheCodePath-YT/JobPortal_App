// import { render } from 'ejs';
import applicantdetailmodel  from '../Models/applicant.models.js'
export default class applicantcontroller {
    // getapplicant(req,res) {
    //     const applicantdata = applicantdetailmodel.applicantmethod();
    //     return res.render('applicant.ejs', {applicantdata});
    // }

    postapplicant(req,res){
    const data=req.body;
    console.log(data);
    applicantdetailmodel.addapplicant(data);
    const applicantdata =applicantdetailmodel.applicantmethod();
    console.log('applicant' , req.body)
    return res.render('applicant.ejs' , {applicantdataa:applicantdata , userEmail:req.session.usermail}); 
      };

      getapplicantbyid(req,res) {
        const applicantid = req.params.id; // Corrected line
        console.log(applicantid);
        const applicantdata = applicantdetailmodel.getbyid(applicantid);
        console.log(applicantdata);
        if (applicantdata) {
            res.render('applicant.ejs', { applicantdataa: applicantdata , userEmail:req.session.usermail});
        } else {
            res.status(400).send("JOB NOT FOUND");
        }
        // next();
    }
    applicantuploadata(req,res,next){
        return res.render('fileuploadsuccessfully.ejs')
        next();
    }
   
}
