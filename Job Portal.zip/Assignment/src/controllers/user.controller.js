
import UserModel from "../Models/user.model.js"

export default class usercontroller {
    getRegister(req,res){
        res.render('register.ejs');
    }
    getlogin(req,res){
        res.render("login.ejs", {errormsg:'',userEmail:req.session.usermail})
    }
    postRegister(req,res){
        const {uname , uemail,upassword} = req.body;
        console.log(req.body);
        UserModel.add(uname,uemail,upassword);
        res.render('login' , {errormsg:'Registration Successful!',userEmail:req.session.usermail});
    }
    postlogin(req, res) {
    const { uemail, upassword } = req.body;
    const user = UserModel.isValidUser(uemail, upassword);
    // const errormsg = user ? '' : 'Invalid Credentials';
    // return res.render('login', { errormsg });
    if (!user) {
        res.render('login.ejs', { errormsg: 'Invalid Credentials' ,userEmail:req.session.usermail });
    } else {
        // Provide an empty errormsg for valid users as well
        res.render('landing.ejs',{errormsg:'',userEmail:req.session.usermail});
    }
    req.session.usermail=uemail;
   
}

    getforgot(req,res){
        res.render("forgot.ejs",{title:'Forgot Password'})
    }
}