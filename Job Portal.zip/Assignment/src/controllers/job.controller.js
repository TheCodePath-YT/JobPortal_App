
import postnewjobmodels from "../Models/postNewJobs.models.js";
export default class postnewjobcontroller{
postnewjobs(req,res){
    // console.log(req.body)
    let jobs = postnewjobmodels.getJobs();
    // console.log(jobs)
    return res.render('job.ejs',{jobs:jobs ,userEmail:req.session.usermail})
}
// jon
// jobid(req,res){
//     // console.log(req.body)
//     let jobss = postnewjobmodels.getJobs();
//     // console.log(jobss)
//     return res.render('jobid.ejs',{jobss:jobss})
// }
// Add JOb
addjob(req, res) {
    let newjob = req.body;
   let jobcategory= req.body.jobcategory;
//    console.log(jobcategory)
    // console.log("Form Data:", newjob);
    postnewjobmodels.addJob(newjob);
    return res.redirect('/jobs',{userEmail:req.session.usermail});
}
// Get by id view details
jobdetailgetbyid(req, res, next) {
    const id = req.params.id; // Corrected line
    console.log(id);
    const jobss = postnewjobmodels.getbyid(id);
    console.log(jobss);
    if (jobss) {
        res.render('jobid.ejs', { jobss: jobss ,userEmail:req.session.usermail});
    } else {
        res.status(400).send("JOB NOT FOUND");
    }
    next();
}

}