import path from "path";
export default class homepageController {
    getHome(req,res) {
     return res.render('landing.ejs')
    }
    getPostJob(req,res){
        // console.log(req.body)
        return res.render('postNewjob.ejs')
    }
    
}   