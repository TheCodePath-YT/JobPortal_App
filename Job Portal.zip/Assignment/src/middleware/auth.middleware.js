export const auth = (req, res, next) => {
    // Check if user is authenticated - i.e., they have a token
    console.log('Authenticating...');
    
    if(req.session.userEmail){
        next();
    } else{
        res.redirect('login');
    }
};