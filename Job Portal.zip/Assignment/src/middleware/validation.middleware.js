
import  {body , validationResult} from 'express-validator'
const validateRequest = async(req,res,next) => {
// const{aname , aemail , acontact , resume} =req.body
let rules=[
    body("aname").notEmpty()
    .withMessage('Name is required'),
    body("aemail").notEmpty()
    .withMessage("Email is required"),
    body('acontact')
      .isFloat({ lt: 10 })
      .withMessage(
        'Invalid contact number'
      ),
    
    body('resume').custom((value, { req }) => {
        if (!req.file) {
          throw new Error('Image is required');
        }
        return true;
      }),

];
await Promise.all(
    rules.map((rule) => rule.run(req))
  );

  // 3. check if there are any errors after running the rules.
  var validationErrors = validationResult(req);
  console.log(validationErrors);
  // 4. if errros, return the error message
  if (!validationErrors.isEmpty()) {
    return res.render('applicant.ejs', {
      errorMessage:
        validationErrors.array()[0].msg,
    });
  }
  next();
};

export default validateRequest;