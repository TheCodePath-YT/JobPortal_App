


export default class postnewjobmodels {
    constructor(id,companyname,jobcategory,joblocation,jobdesignation,salary,applyby,skillsrequired,numberofopenings,applicant,currentDate){
        
        this.id =id
        this.companyname=companyname
        this.jobcategory=jobcategory
        this.joblocation=joblocation
        this.jobdesignation=jobdesignation
        
        this.salary=salary
        this.applyby=applyby
        this.skillsrequired=skillsrequired
        this.numberofopenings=numberofopenings
        this.applicant=applicant
        this.currentDate=currentDate
    }
static getJobs() {
    console.log("jobs data ",jobs)
    return jobs;
}
static addJob(njob) {
    
    let newjobs = new postnewjobmodels(jobs.length + 1 , njob.companyname,njob.jobcategory,njob.joblocation,njob.jobdesignation,njob.salary,njob.applyby,njob.skillsrequired,njob.numberofopenings,njob.applicant,njob.currentDate)
    console.log("data",newjobs)
    jobs.push(newjobs);
}
static getbyid(id) {
    console.log('models', id);
    const job = jobs.find((i) => i.id == id);
    return job ? [job] : []; // Return an array with a single job or an empty array if not found
 }
 


}
const jobs = [new postnewjobmodels(1,"Coding Ninjas","Tech","Gurgaon HR IND Remote","SDE" ,"14-20lpa","30 Aug 2023","","5","1","11/02/2023 : 11:00 Am") ,
new postnewjobmodels(2,"Go Digit","Tech","Pune IND On-Site","Angular Developer" ,"6-10lpa","30 Aug 2023","","7","0","16/03/2024 : 02:00 pm") ,
new postnewjobmodels(3,"Juspay","Tech","Bangalore IND","SDE","20-26lpa","30 Aug 2023","","3","0","11/11/2023 : 07:00 pm") ,
]
const currentDate = new Date().toLocaleString();