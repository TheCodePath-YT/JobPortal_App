export default class UserModel {
    constructor(uid,uname, uemail,upassword) {
        this.uid=uid
        this.uname=uname
        this.uemail = uemail;
        this.upassword=upassword
    }
    static getuser() {
        return userdata;
    }
    static add(uname, uemail,upassword){
        const newUser = new UserModel(users.length + 1,uname,uemail,upassword)
        console.log(newUser)
        users.push(newUser)
    }
    static isValidUser(uemail, upassword) {
        const result = users.find((u) => u.uemail === uemail && u.upassword === upassword);
        return result;
    }
    
}
const users = [];
