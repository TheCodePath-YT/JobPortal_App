export default class applicantdetailmodel {
    constructor(aid, aname, aemail, acontact, resume) {
        this.aid = aid;
        this.aname = aname;
        this.aemail = aemail;
        this.acontact = acontact;
        this.resume = resume;
      }
   
    
   static applicantmethod(){
     return applicantdetail;
    }
    static addapplicant(data){
        console.log('data',data)
        let applicant = new applicantdetailmodel(applicantdetail.length+1 , data.aname , data.aemail,data.acontact,data.resume);
        console.log(applicant)
        applicantdetail.push(applicant);
        return applicantdetail; 
    }
    static getbyid(id) {
      console.log( id);
      const appdata = applicantdetail.find((i) => i.id == id);
      return appdata ? [appdata] : []; // Return an array with a single job or an empty array if not found
   }
}

const applicantdetail = [
    new applicantdetailmodel(1, "shivani", "s@gmail.com", "8787878787", "resume.pdf")
  ];