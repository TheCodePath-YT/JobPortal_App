Develop a job portal website that allow recruiter to post and manage job listing and provides a user friendly platform for job seeker.

<!-- Componants -->
Layout page
landing apge
job listing page
job details page
Applicant list page
login page
New job page
update job page
404 page
<!-- JOb.ejs -->
id
jobcategory
jobdesignation
joblocation
companyname
salary
applyby
skillsrequired
numberofopenings
jobposted
applicants
<!-- applicants -->
applicantid
name
email
contactresumePath
<!-- Refernce -->
Resourse based authentication : https://code.pieces.app/blog/role-based-access-systems-in-nodejs
pagination : 
Rest Best Api : https://restfulapi.net/resource-naming/