import express from 'express'
import expressEjsLayouts from 'express-ejs-layouts';
import homepageController from './src/controllers/landing.controller.js';
// import  jobpost  from './src/controllers/job.controller.js';
import postnewjobcontroller from './src/controllers/job.controller.js';
import applicantcontroller from './src/controllers/applicant.controller.js';
import validationMiddleware from  './src/middleware/validation.middleware.js';
import path from 'path';
import exp from 'constants';
import bodyParser from 'body-parser';
import { uploadFile } from './src/Models/file-upload.middleware.js';
import usercontroller from './src/controllers/user.controller.js';
import session from 'express-session';
import {auth} from './src/middleware/auth.middleware.js';

const server = express();
// parse form data
server.use(express.urlencoded({extended:true}))
server.use(bodyParser.urlencoded({ extended: true }));


server.set("view engine", "ejs");
server.set("views", path.join(path.resolve(),'src','views'));
server.use(express.static(path.resolve("public")));
server.use(session({
    secret:'SecretKey',
    resave:false,
    saveUninitialized:true,
    cookie:{secure:false},
}))
server.use(expressEjsLayouts)
//create an instance
const HomepageController = new homepageController()
console.log(HomepageController.getHome)
server.get("/",HomepageController.getHome)
server.get("/postnewjobs",HomepageController.getPostJob)




const job = new postnewjobcontroller()
server.get("/jobs",job.postnewjobs) //getjob
// server.get("/job/:id",job.jobid)      //view more job detail
server.get("/job/:id",job.jobdetailgetbyid)      //view more job detail
server.post("/addjob", job.addjob); //post new job add job
 
//applicant detail
const ApplicantController= new applicantcontroller()
server.get('/job/applicant/:id', auth,ApplicantController.getapplicantbyid) 
server.post('/job/applicant/:id',auth,uploadFile.single('resume'), ApplicantController.postapplicant) 
server.get('/job/applicant/resumeuploadSuccessfully', auth,ApplicantController.applicantuploadata) 

// registeruser
const Usercontroller = new usercontroller()
server.get('/register', Usercontroller.getRegister)
server.post('/register', Usercontroller.postRegister)
server.get('/login', Usercontroller.getlogin)
server.post('/login', Usercontroller.postlogin)
server.get('/forgot', Usercontroller.getforgot)
// server.post('/register', Usercontroller.postRegister.bind(Usercontroller))
// server.use(express.static('src/views'))
export default server;
